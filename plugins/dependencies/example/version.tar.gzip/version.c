#include "version.h"

static const char* my_version = "1.2.3.SOMETHING";

const char* get_version(void)
{
	return my_version;
}
