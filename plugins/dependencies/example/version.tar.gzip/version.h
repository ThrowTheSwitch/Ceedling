#ifndef VERSION_REPORTER_H
#define VERSION_REPORTER_H

const char* get_version(void);

#endif